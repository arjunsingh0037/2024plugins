Multitenant (report_multitenant)
====================

Multitenant is a report plugin that displays & downloads all tenant's data with their user counts.


Requirements
------------

Moodle 3.9 or greater.

Installation
------------

Install the plugin like any other plugin to folder /report

License
-------

Licensed under the [GNU GPL License](http://www.gnu.org/copyleft/gpl.html).
