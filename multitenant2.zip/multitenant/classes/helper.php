<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Helper class for report_multitenant
 *
 * @package   report_multitenant
 * @category  Report Plugins
 * @copyright 2018 Sandeep Gill {support@lingellearning.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace report_multitenant;

use cache;
use coding_exception;
use context_course;
use core_user;
use dml_exception;
use moodle_exception;
use stdClass;

defined('MOODLE_INTERNAL') || die();

class helper
{
    
    /**
     * Handles records for all table types
     *
     * @param int $dateselect selected date in form or current date
     * @param string $type selected type as enrolled or completed
     * @param int $typevalue type value as 0 or 1
     * @param string $range selected type as enrolled/completed
     * @param string $module module type as field name in table
     * @param int|null $usertype field name in table
     * @returns array to display table data
     * @throws \coding_exception
     * @throws \dml_exception
     */
    public static function get_table_records ($dateselect, $tenantid = 0) {
        global $DB;
       
        return true;
    }

}
