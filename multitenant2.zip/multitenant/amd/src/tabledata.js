define(["jquery", "core/ajax", "core/templates", "core/notification"], function($, ajax, Templates, notification) {
    return {
        init: function() {
            $('#exportCSVButton').click(function() {
                var selecteddate = $('#dated').text();
                //var url = M.cfg.wwwroot + '/report/trainingenrolment/downloadpdf.php?d='+selecteddate;
                window.open(url,'_self' );
            });
        }
    };
});
