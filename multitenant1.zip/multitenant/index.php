<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Multitenant Report Page
 *
 * @package    report_multitenant
 * @copyright  2024 NTT Data DigitalLearning
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__.'/../../config.php');
require_once($CFG->libdir.'/adminlib.php');
require_once("locallib.php");
global $DB, $PAGE, $OUTPUT, $USER;
require_login();
$context = context_system::instance();
$PAGE->set_context($context);
require_capability('report/multitenant:view', $context);

$heading = get_string('multitenant', 'report_multitenant');
$url = new moodle_url('/report/multitenant/index.php');

$PAGE->requires->css('/report/multitenant/styles.css');
$PAGE->set_context($context);
$PAGE->set_url($url);
$PAGE->set_pagelayout('report');
$PAGE->set_title($heading);
$PAGE->set_heading($heading);
$PAGE->navbar->add(get_string('pluginname', 'report_multitenant'), $url);
$PAGE->navbar->add(get_string('view_report', 'report_multitenant'));
echo $OUTPUT->header();

// Handles form to filter tenant(s) by date range.
$filterform = new \report_multitenant\filter_form(null, null, "post");
$filterform->display();

$templatecontext = array();
//generates mustaches template file
echo $OUTPUT->render_from_template('report_multitenant/listdata', $templatecontext);
echo $OUTPUT->footer();


