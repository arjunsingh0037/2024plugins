<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Date Filters
 *
 * @package   report_multitenant
 * @category  Report Plugins
 * @copyright 2024 NTT Data DigitalLearning
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace report_multitenant;

defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once($CFG->libdir . '/formslib.php');


class filter_form extends \moodleform {
    /**
     * Form definition.
     * @throws \HTML_QuickForm_Error
     * @throws \coding_exception
     */
    protected function definition() {
        $mform = $this->_form;
        $mform->addElement('header', 'filterheader', get_string('filter'));
        $opts = ['optional' => false];
        $mform->addElement('date_time_selector', 'startdate', get_string('from'), $opts);
        $mform->addElement('date_time_selector', 'enddate', get_string('to'), $opts);
        $mform->setExpanded('filterheader', true);
        $buttonarray = [
            $mform->createElement('submit', 'submitbutton', get_string('filter')),
            $mform->createElement('cancel'),
        ];
        $mform->addGroup($buttonarray, 'buttonar', '', [' '], false);
    }

    // Validate form data.
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        if ($data['startdate'] > $data['enddate']) {
            $errors['startdate'] = get_string('starttimebeforeendtime', 'report_multitenant');
        }
        return $errors;
    }
}
