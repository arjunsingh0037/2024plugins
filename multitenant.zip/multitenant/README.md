Multitenant (report_mu;titenant)
====================

Melt is a plugin contain other subplugins and own functionality of Melt LMS.

Features
--------
- Microsoft Teams app manifest
- Microsoft Teams Meetings Scheduler
- Dashboard carousels
- Melt Analytics

Microsoft Teams app manifest:
--------
Allow users to:
- Download de Microsoft Teams app aplication for Melt

Carousels:
--------
Allow users to:
- Generate custom carousels for dashboard. 

Requirements
------------

Moodle 3.9 or greater.

Installation
------------

Install the plugin like any other plugin to folder /local/melt

License
-------

Licensed under the [GNU GPL License](http://www.gnu.org/copyleft/gpl.html).
